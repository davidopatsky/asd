import React, { useState } from 'react';
import './App.css';

function App() {
  const [product, setProduct] = useState('Pergola');
  const [width, setWidth] = useState('');
  const [height, setHeight] = useState('');
  const [location, setLocation] = useState('');
  const [result, setResult] = useState(null);

  const calculate = () => {
    const basePrice = 10000; // fiktivní cena
    const transport = 2 * 50 * 15; // fiktivní vzdálenost 50 km
    const screenPrice = 5000;

    const montagePercents = [12, 13, 14, 15];
    const montagePrices = montagePercents.map(p => Math.round(basePrice * p / 100));

    setResult({
      rows: [
        { item: product, size: `${width} × ${height} mm`, price: basePrice },
        { item: 'Screenová roleta ALUX', size: `š. ${width} × v. 2500 mm`, price: screenPrice },
        { item: 'Doprava', size: location, price: transport },
        ...montagePrices.map((m, i) => ({ item: `Montáž ${montagePercents[i]}%`, size: '-', price: m }))
      ]
    });
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>ALUX Kalkulačka</h1>
      <div>
        <label>Typ produktu:
          <select value={product} onChange={e => setProduct(e.target.value)}>
            <option>Pergola</option>
            <option>Screenová roleta ALUX</option>
            <option>Rámové zasklení</option>
            <option>ALUX Glass</option>
          </select>
        </label>
      </div>
      <div>
        <label>Šířka (mm):
          <input type="number" value={width} onChange={e => setWidth(e.target.value)} />
        </label>
      </div>
      <div>
        <label>Výška (mm):
          <input type="number" value={height} onChange={e => setHeight(e.target.value)} />
        </label>
      </div>
      <div>
        <label>Místo dodání:
          <input type="text" value={location} onChange={e => setLocation(e.target.value)} />
        </label>
      </div>
      <button onClick={calculate}>Spočítat</button>
      {result && (
        <table border="1" cellPadding="8" style={{ marginTop: '1rem' }}>
          <thead>
            <tr>
              <th>POLOŽKA</th>
              <th>ROZMĚR</th>
              <th>CENA bez DPH</th>
            </tr>
          </thead>
          <tbody>
            {result.rows.map((row, i) => (
              <tr key={i}>
                <td>{row.item}</td>
                <td>{row.size}</td>
                <td>{row.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
